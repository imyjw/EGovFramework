package com.cosmetic.shop.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "orders") // Order는 SQL 예약어라 테이블명 변경
@Getter
@Setter
@NoArgsConstructor
public class Order {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id")
    private Member member;

    private int totalPrice;
    private LocalDateTime orderDate;

    @Enumerated(EnumType.STRING)
    private OrderStatus status; // ORDER, CANCEL

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<OrderItem> orderItems = new ArrayList<>();

    @OneToOne(mappedBy = "order", cascade = CascadeType.ALL)
    private Delivery delivery;

    public enum OrderStatus {
        ORDER, CANCEL
    }

    public String getStatusKorean() {
        if (this.status == OrderStatus.ORDER) {
            return "주문 완료";
        } else if (this.status == OrderStatus.CANCEL) {
            return "취소/반품";
        }
        return "기타";
    }

    public boolean isCancellable() {
        return this.status == OrderStatus.ORDER;
    }
}