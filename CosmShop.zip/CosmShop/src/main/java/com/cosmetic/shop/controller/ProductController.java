package com.cosmetic.shop.controller;

import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.domain.Product;
import com.cosmetic.shop.service.ProductService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.cosmetic.shop.service.ReviewService;

@Controller
@RequiredArgsConstructor
public class ProductController {

    private final ProductService productService;
    private final ReviewService reviewService;

    //상품 상세 페이지
    @GetMapping("/product/{id}")
    public String detail(@PathVariable Long id, HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (loginMember != null) {
            model.addAttribute("loginMember", loginMember);
        }

        Product product = productService.findById(id);
        model.addAttribute("product", product);

        // ★★★ [추가된 부분] 후기 목록 가져오기 ★★★
        model.addAttribute("reviews", reviewService.findAllByProduct(id));

        return "product/detail";
    }
}