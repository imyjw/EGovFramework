package com.cosmetic.shop.controller;

import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.service.WishlistService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
@RequiredArgsConstructor
public class WishlistController {

    private final WishlistService wishlistService;

    // 위시리스트 추가 요청 (상세페이지에서 버튼 클릭 시)
    @GetMapping("/wishlist/add/{productId}")
    public String add(@PathVariable Long productId, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        if (loginMember == null) return "redirect:/login";

        wishlistService.addWishlist(loginMember, productId);
        return "redirect:/wishlist"; // 추가 후 위시리스트 목록으로 이동
    }

    // 위시리스트 페이지 조회
    @GetMapping("/wishlist")
    public String list(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        if (loginMember == null) return "redirect:/login";

        model.addAttribute("loginMember", loginMember);
        model.addAttribute("wishlist", wishlistService.myWishlist(loginMember));
        return "member/wishlist"; // 템플릿 위치
    }

    // 위시리스트 삭제
    @GetMapping("/wishlist/delete/{id}")
    public String delete(@PathVariable Long id) {
        wishlistService.delete(id);
        return "redirect:/wishlist";
    }
}