package com.cosmetic.shop.repository;

import com.cosmetic.shop.domain.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface MemberRepository extends JpaRepository<Member, Long> {
    Optional<Member> findByUsername(String username);

    // 아이디 찾기용 (이메일로 검색)
    Optional<Member> findByEmail(String email);

    // 비밀번호 찾기용 (아이디와 이메일이 모두 일치해야 함)
    Optional<Member> findByUsernameAndEmail(String username, String email);
}