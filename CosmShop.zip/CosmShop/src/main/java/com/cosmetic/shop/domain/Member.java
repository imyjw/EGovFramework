package com.cosmetic.shop.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Member extends BaseTimeEntity {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username; // 아이디

    @Column(nullable = false)
    private String password;

    private String email;
    private String phone;

    @Enumerated(EnumType.STRING)
    private Role role; // USER, ADMIN

    public enum Role {
        USER, ADMIN
    }
}