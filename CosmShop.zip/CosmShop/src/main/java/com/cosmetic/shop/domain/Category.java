package com.cosmetic.shop.domain;

import jakarta.persistence.*;
import lombok.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Category {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    private Category parent;

    @OneToMany(mappedBy = "parent")
    private List<Category> child = new ArrayList<>();

    // ★★★ [새로 추가된 부분] ★★★
    // 카테고리 입장에서 연결된 상품 리스트를 가져오기 위해 추가
    // mappedBy = "category"는 Product.java의 'category' 필드명을 의미함
    @OneToMany(mappedBy = "category")
    @Builder.Default // 빌더 패턴 사용 시 초기화 유지
    private List<Product> products = new ArrayList<>();
}