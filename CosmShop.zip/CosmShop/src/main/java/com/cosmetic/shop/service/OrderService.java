package com.cosmetic.shop.service;

import com.cosmetic.shop.domain.*;
import com.cosmetic.shop.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final MemberRepository memberRepository;
    private final CartRepository cartRepository;
    private final DeliveryRepository deliveryRepository;
    private final PaymentRepository paymentRepository;
    private final ProductRepository productRepository; // 재고 감소용

    // 주문 생성 (결제 처리 포함)
    @Transactional
    public Long createOrder(Member member, String receiverName, String phone, String address) {
        // 1. 회원 확인 및 장바구니 조회
        Member persistentMember = memberRepository.findById(member.getId()).orElseThrow();
        List<Cart> cartList = cartRepository.findByMember(persistentMember);

        if (cartList.isEmpty()) {
            throw new IllegalStateException("장바구니가 비어있습니다.");
        }

        // 2. 주문(Order) 객체 생성
        Order order = new Order();
        order.setMember(persistentMember);
        order.setOrderDate(LocalDateTime.now());
        order.setStatus(Order.OrderStatus.ORDER);

        int totalPrice = 0;

        // 3. 주문 상세(OrderItem) 생성 및 재고 감소
        for (Cart cart : cartList) {
            Product product = cart.getProduct();

            // 재고 확인 및 감소
            if (product.getStock() < cart.getQuantity()) {
                throw new IllegalStateException("상품 재고가 부족합니다: " + product.getName());
            }
            product.setStock(product.getStock() - cart.getQuantity());

            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order); // 연관관계 설정
            orderItem.setProduct(product);
            orderItem.setQuantity(cart.getQuantity());
            orderItem.setPrice(product.getPrice()); // 구매 당시 가격

            order.getOrderItems().add(orderItem); // 주문에 상세 내역 추가
            totalPrice += (product.getPrice() * cart.getQuantity());
        }
        order.setTotalPrice(totalPrice);

        // 주문 저장 (Cascade 옵션 덕분에 OrderItem도 같이 저장됨)
        orderRepository.save(order);

        // 4. 배송 정보(Delivery) 저장
        Delivery delivery = new Delivery();
        delivery.setOrder(order);
        delivery.setAddress(address);
        delivery.setState(Delivery.DeliveryState.READY);
        delivery.setTrackingNo("TRK" + System.currentTimeMillis()); // 가짜 송장번호
        deliveryRepository.save(delivery);

        // 5. 결제 정보(Payment) 저장
        Payment payment = new Payment();
        payment.setOrder(order);
        payment.setMethod("CARD"); // 카드 결제 가정
        payment.setStatus("PAID");
        payment.setPaidAt(LocalDateTime.now());
        paymentRepository.save(payment);

        // 6. 장바구니 비우기
        cartRepository.deleteAll(cartList);

        return order.getId();
    }

    // 내 주문 목록
    public List<Order> myOrders(Member member) {
        return orderRepository.findByMemberOrderByOrderDateDesc(member);
    }

    // 주문 취소
    @Transactional
    public void cancelOrder(Long orderId) {
        Order order = orderRepository.findById(orderId).orElseThrow();
        // 배송중이 아니면 취소 가능 등 로직 필요하지만 단순화
        order.setStatus(Order.OrderStatus.CANCEL);

        // 재고 원상복구 로직 필요 (생략 or 추가 가능)
        for(OrderItem item : order.getOrderItems()){
            Product p = item.getProduct();
            p.setStock(p.getStock() + item.getQuantity());
        }
    }
}