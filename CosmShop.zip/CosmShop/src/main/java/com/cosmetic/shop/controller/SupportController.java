package com.cosmetic.shop.controller;

import com.cosmetic.shop.domain.Inquiry;
import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.service.SupportService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Controller
@RequiredArgsConstructor
public class SupportController {

    private final SupportService supportService;

    // 1. 고객센터 목록 페이지
    @GetMapping("/support")
    public String list(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (loginMember != null) model.addAttribute("loginMember", loginMember);

        model.addAttribute("inquiries", supportService.findAll());
        return "support/list";
    }

    // 2. 글쓰기 페이지 이동
    @GetMapping("/support/write")
    public String writeForm(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (loginMember == null) return "redirect:/login";

        model.addAttribute("loginMember", loginMember);
        return "support/write";
    }

    // 3. 글쓰기 처리 (파일 업로드)
    @PostMapping("/support/write")
    public String write(String title, String content,
                        @RequestParam("file") MultipartFile file,
                        HttpServletRequest request) throws IOException {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (loginMember == null) return "redirect:/login";

        supportService.saveInquiry(loginMember, title, content, file);
        return "redirect:/support";
    }

    // 4. 글 상세 보기 (기존 메서드 수정)
    @GetMapping("/support/view/{id}")
    public String view(@PathVariable Long id, HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        Inquiry inquiry = supportService.findById(id); // 글 정보 먼저 가져오기

        boolean isAdmin = false;
        boolean isOwner = false; // 작성자 본인 여부

        if (loginMember != null) {
            model.addAttribute("loginMember", loginMember);
            if (loginMember.getRole() == Member.Role.ADMIN) isAdmin = true;

            // 로그인한 사람 ID와 글 작성자 ID가 같으면 주인(Owner)
            if (loginMember.getId().equals(inquiry.getMember().getId())) {
                isOwner = true;
            }
        }

        model.addAttribute("isAdmin", isAdmin);
        model.addAttribute("isOwner", isOwner); // ★ 뷰로 전달
        model.addAttribute("inquiry", inquiry);
        model.addAttribute("comments", supportService.findComments(id));

        return "support/view";
    }

    // 5. 내 문의 내역
    @GetMapping("/support/my")
    public String myInquiry(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (loginMember == null) return "redirect:/login";

        model.addAttribute("loginMember", loginMember);
        model.addAttribute("inquiries", supportService.findByMember(loginMember));
        return "support/my_inquiry";
    }

    // 6. 댓글(답변) 달기 - 관리자 전용
    @PostMapping("/support/comment/{inquiryId}")
    public String addComment(@PathVariable Long inquiryId, String content, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        // 관리자만 가능하도록 체크
        if (loginMember != null && loginMember.getRole() == Member.Role.ADMIN) {
            supportService.saveComment(inquiryId, loginMember, content);
        }
        return "redirect:/support/view/" + inquiryId;
    }

    // 7. 댓글 삭제 - 관리자 전용
    @GetMapping("/support/comment/delete/{inquiryId}/{commentId}")
    public String deleteComment(@PathVariable Long inquiryId, @PathVariable Long commentId) {
        supportService.deleteComment(commentId);
        return "redirect:/support/view/" + inquiryId;
    }

    // [추가] 게시글 삭제
    @GetMapping("/support/delete/{id}")
    public String deleteInquiry(@PathVariable Long id, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (loginMember == null) return "redirect:/login";

        try {
            supportService.deleteInquiry(id, loginMember);
        } catch (IllegalStateException e) {
            // 권한 없음 에러 처리 (생략 가능)
            return "redirect:/support/view/" + id + "?error=auth";
        }
        return "redirect:/support";
    }

    // [추가] 수정 페이지 이동
    @GetMapping("/support/edit/{id}")
    public String editForm(@PathVariable Long id, HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (loginMember == null) return "redirect:/login";

        Inquiry inquiry = supportService.findById(id);

        // 본인이 아니면 튕겨내기
        if (!inquiry.getMember().getId().equals(loginMember.getId())) {
            return "redirect:/support/view/" + id;
        }

        model.addAttribute("loginMember", loginMember);
        model.addAttribute("inquiry", inquiry);
        return "support/edit";
    }

    // [추가] 수정 처리
    @PostMapping("/support/edit/{id}")
    public String update(@PathVariable Long id, String title, String content,
                         @RequestParam("file") MultipartFile file,
                         HttpServletRequest request) throws IOException {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (loginMember == null) return "redirect:/login";

        supportService.updateInquiry(id, loginMember, title, content, file);
        return "redirect:/support/view/" + id;
    }
}