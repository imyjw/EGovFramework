package com.cosmetic.shop.config;

public class SecurityConfig {
}
