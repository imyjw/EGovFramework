package com.cosmetic.shop.domain;

import jakarta.persistence.*;
import lombok.*; // 1. Lombok 어노테이션 임포트 확인

@Entity
@Getter // <--- 2. 이 어노테이션이 없으면 Mustache가 데이터를 못 읽습니다! (필수)
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product extends BaseTimeEntity {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    public String name;
    public int price;

    @Column(length = 1000)
    public String description;

    // 3. 필드명이 템플릿의 {{imageUrl}}과 정확히 일치해야 합니다.
    // imgUrl, image_url 등이 아니라 'imageUrl' 이어야 함
    public String imageUrl;

    public int stock;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    public Category category;

}