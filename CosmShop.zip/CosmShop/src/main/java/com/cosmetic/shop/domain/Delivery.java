package com.cosmetic.shop.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Delivery {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id")
    private Order order;

    private String address;
    private String trackingNo; // 운송장 번호

    @Enumerated(EnumType.STRING)
    private DeliveryState state; // READY, COMP, RETURN

    public enum DeliveryState {
        READY, COMP, RETURN
    }
}