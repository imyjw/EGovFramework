package com.cosmetic.shop.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter // ★ 필수
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Comment extends BaseTimeEntity {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id")
    private Member member; // 작성자(주로 관리자)

    // 후기에 대한 댓글일 경우
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "review_id")
    private Review review;

    // 문의에 대한 댓글(답변)일 경우 (요구사항 3번을 위해 추가)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inquiry_id")
    private Inquiry inquiry;

    private String content;
}