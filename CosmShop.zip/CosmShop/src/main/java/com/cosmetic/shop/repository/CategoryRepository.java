package com.cosmetic.shop.repository;

import com.cosmetic.shop.domain.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    // 카테고리 이름으로 찾기 (상품 등록 시 필요)
    Optional<Category> findByName(String name);
}