package com.cosmetic.shop.repository;

import com.cosmetic.shop.domain.Cart;
import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface CartRepository extends JpaRepository<Cart, Long> {
    // 특정 회원의 장바구니 목록 조회
    List<Cart> findByMember(Member member);

    // 이미 장바구니에 담긴 상품인지 확인 (수량 추가 로직용)
    Optional<Cart> findByMemberAndProduct(Member member, Product product);
}