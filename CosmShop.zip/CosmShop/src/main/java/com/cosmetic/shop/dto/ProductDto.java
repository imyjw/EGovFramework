package com.cosmetic.shop.dto;

public class ProductDto {
}
