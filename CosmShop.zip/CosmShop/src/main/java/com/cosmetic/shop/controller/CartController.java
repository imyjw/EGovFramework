package com.cosmetic.shop.controller;

import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.service.CartService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;

    // 장바구니 담기 (상세페이지에서 폼 전송)
    @PostMapping("/cart/add")
    public String addCart(Long productId, int quantity, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        if (loginMember == null) return "redirect:/login";

        cartService.addCart(loginMember, productId, quantity);
        return "redirect:/cart"; // 장바구니 페이지로 이동
    }

    @PostMapping("/cart/buyNow")
    public String buyNow(Long productId, int quantity, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        if (loginMember == null) return "redirect:/login";

        // 1. 장바구니에 담기 (기존 서비스 재활용)
        cartService.addCart(loginMember, productId, quantity);

        // 2. 바로 주문 페이지로 이동
        return "redirect:/order/checkout";
    }

    // 장바구니 페이지 이동
    @GetMapping("/cart")
    public String cartList(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        if (loginMember == null) return "redirect:/login";

        model.addAttribute("loginMember", loginMember);
        model.addAttribute("cartList", cartService.myCartList(loginMember));
        return "order/cart";
    }

    // 장바구니 삭제
    @GetMapping("/cart/delete/{id}")
    public String deleteCart(@PathVariable Long id) {
        cartService.deleteCart(id);
        return "redirect:/cart";
    }

}