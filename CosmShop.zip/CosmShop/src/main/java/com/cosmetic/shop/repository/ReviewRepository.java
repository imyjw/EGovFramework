package com.cosmetic.shop.repository;

import com.cosmetic.shop.domain.Product;
import com.cosmetic.shop.domain.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    // 특정 상품에 달린 후기 목록 조회
    List<Review> findByProduct(Product product);
}