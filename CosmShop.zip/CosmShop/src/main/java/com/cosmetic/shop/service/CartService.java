package com.cosmetic.shop.service;

import com.cosmetic.shop.domain.Cart;
import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.domain.Product;
import com.cosmetic.shop.repository.CartRepository;
import com.cosmetic.shop.repository.MemberRepository; // 추가
import com.cosmetic.shop.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CartService {

    private final CartRepository cartRepository;
    private final ProductRepository productRepository;
    private final MemberRepository memberRepository;

    // 장바구니 담기
    @Transactional
    public void addCart(Member member, Long productId, int quantity) {
        // 영속성 컨텍스트를 위해 멤버 다시 조회
        Member persistentMember = memberRepository.findById(member.getId()).orElseThrow();
        Product product = productRepository.findById(productId).orElseThrow();

        Cart cart = cartRepository.findByMemberAndProduct(persistentMember, product)
                .orElse(null);

        if (cart == null) {
            cart = new Cart();
            cart.setMember(persistentMember);
            cart.setProduct(product);
            cart.setQuantity(quantity);
            cartRepository.save(cart);
        } else {
            // 이미 있으면 수량 누적
            cart.setQuantity(cart.getQuantity() + quantity);
        }
    }

    // 장바구니 목록 조회
    public List<Cart> myCartList(Member member) {
        return cartRepository.findByMember(member);
    }

    // 장바구니 삭제
    @Transactional
    public void deleteCart(Long id) {
        cartRepository.deleteById(id);
    }
}