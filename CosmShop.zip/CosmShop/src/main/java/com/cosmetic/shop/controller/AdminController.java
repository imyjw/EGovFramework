package com.cosmetic.shop.controller;

import com.cosmetic.shop.domain.Category;
import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.domain.Product;
import com.cosmetic.shop.repository.CategoryRepository;
import com.cosmetic.shop.service.MemberService;
import com.cosmetic.shop.service.ReviewService;
import com.cosmetic.shop.service.ProductService;
import com.cosmetic.shop.service.SupportService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private final ProductService productService;
    private final CategoryRepository categoryRepository; // 카테고리 목록 보여주기 위해

    private final MemberService memberService;
    private final SupportService supportService;
    private final ReviewService reviewService;
    // 관리자 권한 체크용 메서드 (모든 메서드 초입에 사용)
    private Member checkAdmin(HttpServletRequest request) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        if (loginMember != null && loginMember.getRole() == Member.Role.ADMIN) {
            return loginMember;
        }
        return null;
    }

    // 1. 관리자 대시보드 (메인)
    @GetMapping
    public String dashboard(HttpServletRequest request, Model model) {
        Member admin = checkAdmin(request);
        if (admin == null) return "redirect:/"; // 관리자 아니면 쫓아냄

        model.addAttribute("loginMember", admin); // 헤더용
        return "admin/dashboard";
    }

    // 2. 상품 관리 페이지 (목록 보여주기)
    @GetMapping("/products")
    public String productManage(HttpServletRequest request, Model model) {
        Member admin = checkAdmin(request);
        if (admin == null) return "redirect:/";

        model.addAttribute("loginMember", admin);
        model.addAttribute("products", productService.findAll());
        return "admin/product_manage";
    }

    // 3. 상품 등록 페이지 이동
    @GetMapping("/products/new")
    public String productForm(HttpServletRequest request, Model model) {
        Member admin = checkAdmin(request);
        if (admin == null) return "redirect:/";

        model.addAttribute("loginMember", admin);
        model.addAttribute("categories", categoryRepository.findAll());
        return "admin/product_form";
    }

    // 4. 상품 등록 처리 (POST)
    @PostMapping("/products/new")
    public String createProduct(Product product,
                                @RequestParam("file") MultipartFile file,
                                @RequestParam("categoryId") Long categoryId) throws IOException {
        // 관리자 체크는 생략(화면에서 막히므로), 보안 강화하려면 여기서도 checkAdmin 호출 필요
        productService.saveProduct(product, file, categoryId);
        return "redirect:/admin/products";
    }

    // 5. 상품 삭제
    @GetMapping("/products/delete/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return "redirect:/admin/products";
    }

    // ... 기존 Product 관련 코드 아래에 추가 ...

    // ====================
    // 2. 카테고리 관리 기능
    // ====================

    // 카테고리 관리 페이지 (목록 보여주기)
    @GetMapping("/categories")
    public String categoryManage(HttpServletRequest request, Model model) {
        Member admin = checkAdmin(request);
        if (admin == null) return "redirect:/";

        model.addAttribute("loginMember", admin);
        model.addAttribute("categories", categoryRepository.findAll());
        return "admin/category_manage";
    }

    // 카테고리 추가 (POST)
    @PostMapping("/categories/new")
    public String createCategory(String name) {
        // 간단하게 이름만 받아서 생성 (부모 카테고리 로직은 생략하고 1차 카테고리로 생성)
        Category category = new Category();
        category.setName(name);
        categoryRepository.save(category);
        return "redirect:/admin/categories";
    }

    // 카테고리 삭제
    @GetMapping("/categories/delete/{id}")
    public String deleteCategory(@PathVariable Long id) {
        // 주의: 해당 카테고리를 쓰는 상품이 있으면 에러가 날 수 있음 (FK 제약조건)
        // 실무에선 상품의 카테고리를 null로 바꾸거나 막아야 하지만, 여기선 강제 삭제 시도
        try {
            categoryRepository.deleteById(id);
        } catch (Exception e) {
            // 삭제 실패 시 (상품이 연결된 경우 등) 그냥 목록으로 리턴
            return "redirect:/admin/categories?error=linked";
        }
        return "redirect:/admin/categories";
    }

    // ====================
    // 3. 회원 관리 기능
    // ====================

    // 회원 관리 페이지 (목록 보여주기)
    @GetMapping("/members")
    public String memberManage(HttpServletRequest request, Model model) {
        Member admin = checkAdmin(request);
        if (admin == null) return "redirect:/";

        model.addAttribute("loginMember", admin);
        // MemberService에 findAll 메서드가 필요합니다!
        model.addAttribute("members", memberService.findAll());
        return "admin/member_manage";
    }

    // 회원 강제 탈퇴
    @GetMapping("/members/delete/{id}")
    public String deleteMember(@PathVariable Long id) {
        memberService.deleteMember(id);
        return "redirect:/admin/members";
    }

    // ====================
    // 4. 고객센터 문의 관리 (새로 추가)
    // ====================

    // 문의글 관리 페이지 (목록)
    @GetMapping("/supports")
    public String supportManage(HttpServletRequest request, Model model) {
        Member admin = checkAdmin(request);
        if (admin == null) return "redirect:/";

        model.addAttribute("loginMember", admin);
        // 모든 문의글 가져오기
        model.addAttribute("inquiries", supportService.findAll());
        return "admin/support_manage";
    }

    // 문의글 강제 삭제
    @GetMapping("/supports/delete/{id}")
    public String deleteSupport(@PathVariable Long id, HttpServletRequest request) {
        Member admin = checkAdmin(request);
        if (admin == null) return "redirect:/";

        // 관리자 권한으로 삭제
        supportService.deleteInquiry(id, admin);
        return "redirect:/admin/supports";
    }

    // ====================
    // 5. 상품 후기 관리 (새로 추가)
    // ====================

    // 후기 관리 페이지 (목록)
    @GetMapping("/reviews")
    public String reviewManage(HttpServletRequest request, Model model) {
        Member admin = checkAdmin(request);
        if (admin == null) return "redirect:/";

        model.addAttribute("loginMember", admin);
        model.addAttribute("reviews", reviewService.findAll()); // 전체 후기 가져오기
        return "admin/review_manage";
    }

    // 후기 강제 삭제
    @GetMapping("/reviews/delete/{id}")
    public String deleteReview(@PathVariable Long id, HttpServletRequest request) {
        Member admin = checkAdmin(request);
        if (admin == null) return "redirect:/";

        // 이미 Service에 관리자 삭제 권한 로직이 구현되어 있으므로 호출만 하면 됩니다.
        reviewService.deleteReview(id, admin);

        return "redirect:/admin/reviews";
    }
}