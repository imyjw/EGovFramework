package com.cosmetic.shop.service;

import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MemberService {

    // [중요] final이 있어야 스프링이 repository를 넣어줍니다.
    // final이 없으면 repository는 null 상태가 되고, 에러가 납니다.
    private final MemberRepository memberRepository;

    @Transactional
    public void join(Member member) {
        if(memberRepository.findByUsername(member.getUsername()).isPresent()){
            throw new IllegalStateException("이미 존재하는 아이디입니다.");
        }
        memberRepository.save(member);
    }

    public Member login(String username, String password) {
        return memberRepository.findByUsername(username)
                .filter(m -> m.getPassword().equals(password))
                .orElse(null);
    }

    public String findUsername(String email) {
        return memberRepository.findByEmail(email)
                .map(Member::getUsername)
                .orElse(null);
    }

    public String findPassword(String username, String email) {
        return memberRepository.findByUsernameAndEmail(username, email)
                .map(Member::getPassword)
                .orElse(null);
    }

    @Transactional
    public void update(Member sessionMember, Member formMember) {
        Member member = memberRepository.findById(sessionMember.getId())
                .orElseThrow(() -> new IllegalArgumentException("회원이 존재하지 않습니다."));

        if (formMember.getPassword() != null && !formMember.getPassword().isEmpty()) {
            member.setPassword(formMember.getPassword());
        }
        member.setEmail(formMember.getEmail());
        member.setPhone(formMember.getPhone());
    }

    // 관리자용: 전체 회원 조회
    public List<Member> findAll() {
        return memberRepository.findAll();
    }

    // 관리자용: 회원 삭제
    @Transactional
    public void deleteMember(Long id) {
        memberRepository.deleteById(id);
    }

    // 아이디 중복 체크 (true면 중복, false면 사용 가능)
    public boolean checkUsernameDuplicate(String username) {
        return memberRepository.findByUsername(username).isPresent();
    }

    // 이메일 중복 체크 (true면 중복)
    public boolean checkEmailDuplicate(String email) {
        return memberRepository.findByEmail(email).isPresent();
    }
}