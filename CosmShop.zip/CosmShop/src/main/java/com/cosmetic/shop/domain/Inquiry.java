package com.cosmetic.shop.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter // ★ 필수
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Inquiry extends BaseTimeEntity {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id")
    private Member member;

    private String title;

    @Column(length = 1000)
    private String content;

    private String attachedFileUrl; // 첨부파일 경로
}