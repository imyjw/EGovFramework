package com.cosmetic.shop.repository;

import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.domain.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {
    // 내 주문 내역 조회 (최신순 정렬)
    List<Order> findByMemberOrderByOrderDateDesc(Member member);
}