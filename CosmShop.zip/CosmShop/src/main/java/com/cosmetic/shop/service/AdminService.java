package com.cosmetic.shop.service;

public class AdminService {
}
