package com.cosmetic.shop;

import com.cosmetic.shop.domain.Category;
import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.domain.Product;
import com.cosmetic.shop.repository.CategoryRepository;
import com.cosmetic.shop.repository.MemberRepository;
import com.cosmetic.shop.repository.ProductRepository; // 추가됨
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@EnableJpaAuditing
@SpringBootApplication
public class CosmShopApplication {

    public static void main(String[] args) {
        SpringApplication.run(CosmShopApplication.class, args);
    }

    // 서버 실행 시 초기 데이터 자동 삽입
    @Bean
    public CommandLineRunner initData(CategoryRepository categoryRepository,
                                      MemberRepository memberRepository,
                                      ProductRepository productRepository) {
        return args -> {
            // 1. 관리자 계정 생성 (없을 경우에만)
            if (memberRepository.findByUsername("admin").isEmpty()) {
                Member admin = new Member();
                admin.setUsername("admin");
                admin.setPassword("1234");
                admin.setEmail("admin@shop.com");
                admin.setPhone("010-1234-5678");
                admin.setRole(Member.Role.ADMIN);
                memberRepository.save(admin);
            }

            // 2. 카테고리 생성 및 조회 (스킨, 로션)
            // orElseGet을 사용하여 이미 있으면 가져오고, 없으면 생성해서 저장
            Category skin = categoryRepository.findByName("스킨").orElseGet(() -> {
                Category c = new Category();
                c.setName("스킨");
                return categoryRepository.save(c);
            });

            Category lotion = categoryRepository.findByName("로션").orElseGet(() -> {
                Category c = new Category();
                c.setName("로션");
                return categoryRepository.save(c);
            });

            // ... (생략) ...

            // 3. 상품 데이터 생성 (상품이 하나도 없을 때만 4개 추가)
            if (productRepository.count() == 0) {
                // [스킨 1]
                Product p1 = new Product();
                p1.setName("촉촉한 녹차 스킨");
                p1.setPrice(12000);
                p1.setStock(100);
                p1.setDescription("제주 유기농 녹차로 만든 수분 가득 스킨입니다.");
                p1.setCategory(skin);
                p1.imageUrl = "skin_green_tea.jpg"; // ★★★ 이 부분 추가 ★★★
                productRepository.save(p1);

                // [스킨 2]
                Product p2 = new Product();
                p2.setName("히알루론산 토너");
                p2.setPrice(18000);
                p2.setStock(50);
                p2.setDescription("속건조를 잡아주는 강력한 보습 토너입니다.");
                p2.setCategory(skin);
                p2.imageUrl = "skin_hyaluronic.jpg"; // ★★★ 이 부분 추가 ★★★
                productRepository.save(p2);

                // [로션 1]
                Product p3 = new Product();
                p3.setName("데일리 모이스처 로션");
                p3.setPrice(22000);
                p3.setStock(80);
                p3.setDescription("끈적임 없이 산뜻한 데일리 로션입니다.");
                p3.setCategory(lotion);
                p3.imageUrl = "lotion_daily.jpg"; // ★★★ 이 부분 추가 ★★★
                productRepository.save(p3);

                // [로션 2]
                Product p4 = new Product();
                p4.setName("프리미엄 안티에이징 로션");
                p4.setPrice(45000);
                p4.setStock(30);
                p4.setDescription("주름 개선 기능성 인증을 받은 프리미엄 로션.");
                p4.setCategory(lotion);
                p4.imageUrl = "lotion_premium.jpg"; // ★★★ 이 부분 추가 ★★★
                productRepository.save(p4);
            }
        };
    }
}