package com.cosmetic.shop.repository;

import com.cosmetic.shop.domain.Comment;
import com.cosmetic.shop.domain.Inquiry;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    // 특정 문의글에 달린 답변(댓글) 조회
    List<Comment> findByInquiry(Inquiry inquiry);
}