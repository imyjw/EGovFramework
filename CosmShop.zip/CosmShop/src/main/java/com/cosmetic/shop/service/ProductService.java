package com.cosmetic.shop.service;

import com.cosmetic.shop.domain.Category;
import com.cosmetic.shop.domain.Product;
import com.cosmetic.shop.repository.CategoryRepository;
import com.cosmetic.shop.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    // 상품 등록 (이미지 처리 포함)
    @Transactional
    public void saveProduct(Product product, MultipartFile file, Long categoryId) throws IOException {
        // 1. 카테고리 설정
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new IllegalArgumentException("카테고리가 없습니다."));
        product.setCategory(category);

        // 2. 파일 업로드 처리
        if (file != null && !file.isEmpty()) {
            // 저장할 경로 지정 (프로젝트 루트/uploads)
            String uploadDir = System.getProperty("user.dir") + "/uploads";
            File dir = new File(uploadDir);
            if (!dir.exists()) dir.mkdirs(); // 폴더 없으면 생성

            // 파일명 중복 방지를 위해 UUID 사용
            String originalFilename = file.getOriginalFilename();
            String savedFilename = UUID.randomUUID() + "_" + originalFilename;

            // 실제 파일 저장
            file.transferTo(new File(uploadDir + "/" + savedFilename));

            // DB에는 파일 이름만 저장
            product.setImageUrl(savedFilename);
        }

        productRepository.save(product);
    }

    // 전체 상품 조회
    public List<Product> findAll() {
        return productRepository.findAll();
    }

    // 상품 삭제
    @Transactional
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

    // 카테고리 이름으로 상품 목록 조회 (메인 페이지용)
    public List<Product> findByCategory(String categoryName) {
        return productRepository.findByCategory_Name(categoryName);
    }

    // 상품 상세 조회 (상세 페이지용)
    public Product findById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 상품이 없습니다. id=" + id));
    }
}