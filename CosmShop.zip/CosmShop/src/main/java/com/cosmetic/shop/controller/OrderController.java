package com.cosmetic.shop.controller;

import com.cosmetic.shop.domain.Cart;
import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.service.CartService;
import com.cosmetic.shop.service.OrderService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;
    private final CartService cartService;

    // 주문서 작성 페이지 (Checkout)
    @GetMapping("/order/checkout")
    public String checkout(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (loginMember == null) return "redirect:/login";

        List<Cart> cartList = cartService.myCartList(loginMember);
        if (cartList.isEmpty()) return "redirect:/cart";

        int totalPrice = cartList.stream().mapToInt(c -> c.getProduct().getPrice() * c.getQuantity()).sum();

        model.addAttribute("loginMember", loginMember);
        model.addAttribute("cartList", cartList);
        model.addAttribute("totalPrice", totalPrice);

        return "order/checkout";
    }

    // 주문 처리 (결제하기 버튼 클릭 시)
    @PostMapping("/order/process")
    public String processOrder(String receiverName, String phone, String address,
                               HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        try {
            Long orderId = orderService.createOrder(loginMember, receiverName, phone, address);
            model.addAttribute("message", "주문이 완료되었습니다!");
            model.addAttribute("redirectUrl", "/order/history"); // 확인 누르면 이동할 곳
            return "order/result"; // 안내 메시지 페이지
        } catch (IllegalStateException e) {
            model.addAttribute("message", "주문 실패: " + e.getMessage());
            return "order/result";
        }
    }

    // 주문 내역 페이지
    @GetMapping("/order/history")
    public String history(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (loginMember == null) return "redirect:/login";

        model.addAttribute("loginMember", loginMember);
        model.addAttribute("orders", orderService.myOrders(loginMember));
        return "order/history";
    }

    // 주문 취소/반품
    @GetMapping("/order/cancel/{id}")
    public String cancel(@PathVariable Long id, Model model) {
        orderService.cancelOrder(id);

        model.addAttribute("message", "반품 신청이 완료되었습니다."); // 요구사항 반영
        model.addAttribute("redirectUrl", "/order/history");

        return "order/result"; // 메시지를 띄워주는 공통 페이지 재사용
    }
}