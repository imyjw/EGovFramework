package com.cosmetic.shop.repository;

import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.domain.Product;
import com.cosmetic.shop.domain.Wishlist;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface WishlistRepository extends JpaRepository<Wishlist, Long> {
    // 내 위시리스트 목록 찾기
    List<Wishlist> findByMember(Member member);

    // 이미 찜한 상품인지 확인
    Optional<Wishlist> findByMemberAndProduct(Member member, Product product);
}