package com.cosmetic.shop.service;

import com.cosmetic.shop.domain.Comment;
import com.cosmetic.shop.domain.Inquiry;
import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.repository.CommentRepository;
import com.cosmetic.shop.repository.InquiryRepository;
import com.cosmetic.shop.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class SupportService {

    private final InquiryRepository inquiryRepository;
    private final CommentRepository commentRepository;
    private final MemberRepository memberRepository;

    // 문의글 저장 (파일 처리 포함)
    @Transactional
    public void saveInquiry(Member member, String title, String content, MultipartFile file) throws IOException {
        Inquiry inquiry = new Inquiry();
        inquiry.setMember(member);
        inquiry.setTitle(title);
        inquiry.setContent(content);

        // 파일 업로드 로직 (ProductService와 동일)
        if (file != null && !file.isEmpty()) {
            String uploadDir = System.getProperty("user.dir") + "/uploads";
            File dir = new File(uploadDir);
            if (!dir.exists()) dir.mkdirs();

            String savedFilename = UUID.randomUUID() + "_" + file.getOriginalFilename();
            file.transferTo(new File(uploadDir + "/" + savedFilename));
            inquiry.setAttachedFileUrl(savedFilename);
        }

        inquiryRepository.save(inquiry);
    }

    // 전체 문의글 조회
    public List<Inquiry> findAll() {
        return inquiryRepository.findAll();
    }

    // 내 문의글 조회
    public List<Inquiry> findByMember(Member member) {
        return inquiryRepository.findByMember(member);
    }

    // 상세 조회
    public Inquiry findById(Long id) {
        return inquiryRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("글이 없습니다."));
    }

    // 댓글(답변) 저장
    @Transactional
    public void saveComment(Long inquiryId, Member admin, String content) {
        Inquiry inquiry = inquiryRepository.findById(inquiryId).orElseThrow();

        Comment comment = new Comment();
        comment.setInquiry(inquiry);
        comment.setMember(admin);
        comment.setContent(content);

        commentRepository.save(comment);
    }

    // 해당 글의 댓글 목록 조회
    public List<Comment> findComments(Long inquiryId) {
        Inquiry inquiry = inquiryRepository.findById(inquiryId).orElseThrow();
        return commentRepository.findByInquiry(inquiry);
    }

    // 댓글 삭제 (관리자용)
    @Transactional
    public void deleteComment(Long commentId) {
        commentRepository.deleteById(commentId);
    }

    // ... 기존 코드들 ...

    // 게시글 삭제 (관리자 OR 작성자 본인)
    @Transactional
    public void deleteInquiry(Long id, Member member) {
        Inquiry inquiry = inquiryRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다."));

        // [수정된 부분] 관리자이거나, 작성자 본인인 경우에만 삭제 허용
        if (member.getRole() != Member.Role.ADMIN && !inquiry.getMember().getId().equals(member.getId())) {
            throw new IllegalStateException("삭제 권한이 없습니다.");
        }

        inquiryRepository.delete(inquiry);
    }

    // 게시글 수정 (파일 수정 포함)
    @Transactional
    public void updateInquiry(Long id, Member member, String title, String content, MultipartFile file) throws IOException {
        Inquiry inquiry = inquiryRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다."));

        if (!inquiry.getMember().getId().equals(member.getId())) {
            throw new IllegalStateException("수정 권한이 없습니다.");
        }

        // 제목, 내용 업데이트
        inquiry.setTitle(title);
        inquiry.setContent(content);

        // 새 파일이 들어왔을 때만 교체
        if (file != null && !file.isEmpty()) {
            String uploadDir = System.getProperty("user.dir") + "/uploads";
            String savedFilename = UUID.randomUUID() + "_" + file.getOriginalFilename();
            file.transferTo(new File(uploadDir + "/" + savedFilename));

            inquiry.setAttachedFileUrl(savedFilename);
        }
    }
}