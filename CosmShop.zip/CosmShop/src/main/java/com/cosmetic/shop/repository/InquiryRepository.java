package com.cosmetic.shop.repository;

import com.cosmetic.shop.domain.Inquiry;
import com.cosmetic.shop.domain.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InquiryRepository extends JpaRepository<Inquiry, Long> {
    // 내 문의 내역 조회
    List<Inquiry> findByMember(Member member);
}