package com.cosmetic.shop.controller;

import com.cosmetic.shop.domain.Category;
import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.repository.CategoryRepository; // Service 대신 Repository 바로 사용
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class MainController {

    // ProductService 대신 CategoryRepository를 주입받습니다.
    private final CategoryRepository categoryRepository;

    @GetMapping("/")
    public String main(HttpServletRequest request, Model model) {
        // 1. 로그인 세션 처리
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (loginMember != null) {
            model.addAttribute("loginMember", loginMember);
        }

        // 2. 모든 카테고리 조회
        // (Entity에 products 리스트가 있으므로, 카테고리만 가져오면 상품도 딸려옵니다)
        List<Category> allCategories = categoryRepository.findAll();
        model.addAttribute("categories", allCategories);

        return "main";
    }
}