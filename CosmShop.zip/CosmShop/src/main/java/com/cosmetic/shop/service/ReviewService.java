package com.cosmetic.shop.service;

import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.domain.Product;
import com.cosmetic.shop.domain.Review;
import com.cosmetic.shop.repository.ProductRepository;
import com.cosmetic.shop.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final ProductRepository productRepository;

    // 후기 저장
    @Transactional
    public void saveReview(Member member, Long productId, int rating, String content) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new IllegalArgumentException("상품이 없습니다."));

        Review review = new Review();
        review.setMember(member);
        review.setProduct(product);
        review.setRating(rating);
        review.setContent(content);

        reviewRepository.save(review);
    }

    // 특정 상품의 후기 목록 조회
    public List<Review> findAllByProduct(Long productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new IllegalArgumentException("상품이 없습니다."));
        return reviewRepository.findByProduct(product);
    }

    // 후기 삭제 (작성자 본인 또는 관리자)
    @Transactional
    public void deleteReview(Long reviewId, Member member) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("후기가 없습니다."));

        // 권한 체크
        if (member.getRole() != Member.Role.ADMIN && !review.getMember().getId().equals(member.getId())) {
            throw new IllegalStateException("삭제 권한이 없습니다.");
        }
        reviewRepository.delete(review);
    }

    // 후기 수정
    @Transactional
    public void updateReview(Long reviewId, Member member, int rating, String content) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("후기가 없습니다."));

        // 작성자 본인 확인
        if (!review.getMember().getId().equals(member.getId())) {
            throw new IllegalStateException("수정 권한이 없습니다.");
        }

        review.setRating(rating);
        review.setContent(content);
    }

    // [추가] 모든 후기 조회 (관리자용)
    public List<Review> findAll() {
        return reviewRepository.findAll();
    }
}