package com.cosmetic.shop.controller;

import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.service.ReviewService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    // 후기 작성 (상품 상세페이지에서 POST 요청)
    @PostMapping("/review/create")
    public String create(Long productId, int rating, String content, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        if (loginMember == null) return "redirect:/login";

        reviewService.saveReview(loginMember, productId, rating, content);

        // 작성 후 다시 해당 상품 상세 페이지로 돌아감
        return "redirect:/product/" + productId;
    }

    // 후기 삭제
    @GetMapping("/review/delete/{productId}/{reviewId}")
    public String delete(@PathVariable Long productId, @PathVariable Long reviewId, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        if (loginMember == null) return "redirect:/login";

        try {
            reviewService.deleteReview(reviewId, loginMember);
        } catch (IllegalStateException e) {
            // 권한 없음 처리 (생략 가능)
        }
        return "redirect:/product/" + productId;
    }

    // 후기 수정 처리
    @PostMapping("/review/update")
    public String update(Long reviewId, Long productId, int rating, String content, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        if (loginMember == null) return "redirect:/login";

        try {
            reviewService.updateReview(reviewId, loginMember, rating, content);
        } catch (IllegalStateException e) {
            // 권한 없음 예외 처리 (생략 가능)
        }
        return "redirect:/product/" + productId;
    }
}