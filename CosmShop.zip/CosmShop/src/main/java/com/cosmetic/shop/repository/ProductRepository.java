package com.cosmetic.shop.repository;

import com.cosmetic.shop.domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    // 카테고리 이름으로 상품 목록 조회 (예: "스킨", "로션")
    List<Product> findByCategory_Name(String categoryName);
}