package com.cosmetic.shop.controller;

import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.service.MemberService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequiredArgsConstructor
public class MemberController {

    private final MemberService memberService;

    // 회원가입 페이지 이동
    @GetMapping("/join")
    public String joinPage() {
        return "member/join";
    }

    // 회원가입 처리
    @PostMapping("/join")
    public String join(Member member) {
        // 원래는 DTO를 써야 하지만, 편의상 Entity를 바로 사용합니다.
        // 약관 동의 로직 등은 프론트엔드(HTML)에서 필수로 받거나 여기서 체크 가능
        memberService.join(member);
        return "redirect:/login";
    }

    // 로그인 페이지 이동
    @GetMapping("/login")
    public String loginPage() {
        return "member/login";
    }

    // 로그인 처리
    @PostMapping("/login")
    public String login(String username, String password, HttpServletRequest request) {
        Member loginMember = memberService.login(username, password);

        if (loginMember == null) {
            return "redirect:/login?error"; // 실패 시 다시 로그인 페이지
        }

        // 로그인 성공 처리: 세션에 회원 정보 저장
        HttpSession session = request.getSession();
        session.setAttribute("loginMember", loginMember);

        return "redirect:/"; // 메인 페이지로 이동
    }

    // 아이디 중복 체크 API
    // @ResponseBody: 뷰(HTML)를 찾는게 아니라 데이터를 그대로 반환함
    @GetMapping("/api/check-username")
    @ResponseBody
    public boolean checkUsername(@RequestParam("username") String username) {
        return memberService.checkUsernameDuplicate(username);
    }

    // 이메일 중복 체크 API
    @GetMapping("/api/check-email")
    @ResponseBody
    public boolean checkEmail(@RequestParam("email") String email) {
        return memberService.checkEmailDuplicate(email);
    }

    // 로그아웃
    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate(); // 세션 날리기
        }
        return "redirect:/";
    }


    // 아이디/비번 찾기 페이지 이동
    @GetMapping("/find")
    public String findPage() {
        return "member/find";
    }

    // 아이디 찾기 요청
    @PostMapping("/find/id")
    public String findId(String email, Model model) {
        String username = memberService.findUsername(email);
        if (username != null) {
            model.addAttribute("message", "찾으시는 아이디는 " + username + " 입니다.");
        } else {
            model.addAttribute("error", "해당 이메일로 등록된 아이디가 없습니다.");
        }
        return "member/find";
    }

    // 비밀번호 찾기 요청
    @PostMapping("/find/pw")
    public String findPw(String username, String email, Model model) {
        String password = memberService.findPassword(username, email);
        if (password != null) {
            model.addAttribute("message", "회원님의 비밀번호는 " + password + " 입니다.");
        } else {
            model.addAttribute("error", "일치하는 회원 정보가 없습니다.");
        }
        return "member/find";
    }

    // 마이페이지 이동
    @GetMapping("/mypage")
    public String myPage(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        if (loginMember == null) return "redirect:/login";

        model.addAttribute("loginMember", loginMember);
        return "member/mypage";
    }

    // 회원 정보 수정 요청
    @PostMapping("/mypage/update")
    public String updateMember(Member formMember, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Member loginMember = (Member) session.getAttribute("loginMember");

        if (loginMember == null) return "redirect:/login";

        // 서비스에 수정 요청 (세션에 있는 ID를 기반으로 수정)
        memberService.update(loginMember, formMember);

        // 세션 정보도 갱신해줘야 함 (안 그러면 로그아웃 했다 들어와야 바뀐게 보임)
        loginMember.setEmail(formMember.getEmail());
        loginMember.setPhone(formMember.getPhone());
        if(formMember.getPassword() != null && !formMember.getPassword().isEmpty()){
            loginMember.setPassword(formMember.getPassword());
        }
        session.setAttribute("loginMember", loginMember);

        return "redirect:/mypage";
    }
}