package com.cosmetic.shop.service;

import com.cosmetic.shop.domain.Member;
import com.cosmetic.shop.domain.Product;
import com.cosmetic.shop.domain.Wishlist;
import com.cosmetic.shop.repository.MemberRepository;
import com.cosmetic.shop.repository.ProductRepository;
import com.cosmetic.shop.repository.WishlistRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class WishlistService {

    private final WishlistRepository wishlistRepository;
    private final ProductRepository productRepository;
    private final MemberRepository memberRepository;

    // 위시리스트 추가 (중복 체크 포함)
    @Transactional
    public void addWishlist(Member member, Long productId) {
        Member persistentMember = memberRepository.findById(member.getId()).orElseThrow();
        Product product = productRepository.findById(productId).orElseThrow();

        // 이미 찜했는지 확인
        if (wishlistRepository.findByMemberAndProduct(persistentMember, product).isPresent()) {
            return; // 이미 있으면 아무것도 안 함 (또는 에러 발생 가능)
        }

        Wishlist wishlist = new Wishlist();
        wishlist.setMember(persistentMember);
        wishlist.setProduct(product);
        wishlistRepository.save(wishlist);
    }

    // 내 위시리스트 조회
    public List<Wishlist> myWishlist(Member member) {
        return wishlistRepository.findByMember(member);
    }

    // 삭제
    @Transactional
    public void delete(Long id) {
        wishlistRepository.deleteById(id);
    }
}