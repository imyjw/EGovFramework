INSERT INTO article(title,content) VALUES('가가가가','1111');
INSERT INTO article(title,content) VALUES('나나나나','2222');
INSERT INTO article(title,content) VALUES('다다다다','3333');

INSERT INTO article(title,content) VALUES('당신의인생영화는?','댓글 고');
INSERT INTO article(title,content) VALUES('당신의소울푸드는?','댓글 고고');
INSERT INTO article(title,content) VALUES('당신의 취미는?','댓글 고고고');



INSERT INTO comment(article_id, nickname, body) VALUES(4,'Park','굿 윌 헌팅');
INSERT INTO comment(article_id, nickname, body) VALUES(4,'Kim','리얼 스틸');
INSERT INTO comment(article_id, nickname, body) VALUES(4,'Choi','죽은시인들의 사회');

INSERT INTO comment(article_id, nickname, body) VALUES(5,'Park','샤브샤브');
INSERT INTO comment(article_id, nickname, body) VALUES(5,'Kim','마라탕');
INSERT INTO comment(article_id, nickname, body) VALUES(5,'Choi','치킨');

INSERT INTO comment(article_id, nickname, body) VALUES(6,'Park','운동');
INSERT INTO comment(article_id, nickname, body) VALUES(6,'Kim','유튜브');
INSERT INTO comment(article_id, nickname, body) VALUES(6,'Choi','독서');